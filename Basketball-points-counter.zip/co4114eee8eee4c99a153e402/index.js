let homeScore = document.getElementById("home-score")
let guestScore = document.getElementById("guest-score")
let pointhome = 0
let pointguest = 0
//HOME SECTION------------------------
function plus1home(){
    pointhome += 1
    homeScore.textContent = pointhome
}
function plus2home(){
    pointhome += 2
    homeScore.textContent = pointhome
}
function plus3home(){
    pointhome += 3
    homeScore.textContent = pointhome
}
function decrease1home(){
    pointhome -= 1
    homeScore.textContent = pointhome
}


// GUEST SECTION-----------------------
function plus1guest(){
    pointguest += 1
    guestScore.textContent = pointguest
}
function plus2guest(){
    pointguest += 2
    guestScore.textContent = pointguest
}
function plus3guest(){
    pointguest += 3
    guestScore.textContent = pointguest
}
function decrease1guest(){
    pointguest -= 1
    guestScore.textContent = pointguest
}
function restartButton(){
    pointguest = 0
    pointhome = 0
    guestScore.textContent = pointguest
    homeScore.textContent = pointhome
}

